## Are you having configuration troubles?

Please go to [this link](https://github.com/UBCx-Software-Construction/intro-to-softconst-lecture-starters/blob/master/README.md) to try to sort the problem out. If all else fails, feel free to post about it on the discussion board: remember to indicate what repo you're having the problem in, and what exactly is going wrong. 